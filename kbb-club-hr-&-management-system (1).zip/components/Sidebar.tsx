
import React from 'react';
import { UserRole } from '../types';
import { 
  LayoutDashboard, 
  Users, 
  Clock, 
  LogOut, 
  ShieldCheck,
  Wallet,
  ShoppingBag,
  Map as MapIcon
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  role: UserRole;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, role, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: [UserRole.BOSS, UserRole.MANAGER, UserRole.PR, UserRole.CASHIER] },
    { id: 'pos', label: 'POS / Ordering', icon: ShoppingBag, roles: [UserRole.BOSS, UserRole.CASHIER, UserRole.PR] },
    { id: 'booking', label: 'Floor Plan', icon: MapIcon, roles: [UserRole.BOSS, UserRole.MANAGER, UserRole.PR] },
    { id: 'attendance', label: 'Attendance', icon: Clock, roles: [UserRole.PR, UserRole.MANAGER] },
    { id: 'membership', label: 'Membership', icon: Users, roles: [UserRole.BOSS, UserRole.MANAGER, UserRole.PR, UserRole.CASHIER] },
    { id: 'cashier', label: 'Settlement', icon: Wallet, roles: [UserRole.BOSS, UserRole.CASHIER] },
  ];

  const filteredItems = menuItems.filter(item => item.roles.includes(role));

  return (
    <div className="w-20 md:w-64 bg-slate-900 text-white flex flex-col transition-all duration-300">
      <div className="p-4 md:p-6 text-xl font-bold border-b border-slate-800 flex items-center justify-center md:justify-start">
        <ShieldCheck className="w-8 h-8 text-indigo-400 mr-2" />
        <span className="hidden md:inline">KBB Club HR</span>
      </div>
      
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {filteredItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center p-3 rounded-lg transition-colors ${
              activeTab === item.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <item.icon className="w-6 h-6" />
            <span className="ml-3 hidden md:inline font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button 
          onClick={onLogout}
          className="w-full flex items-center p-3 text-slate-400 hover:text-red-400 transition-colors"
        >
          <LogOut className="w-6 h-6" />
          <span className="ml-3 hidden md:inline font-medium">Log Out</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
