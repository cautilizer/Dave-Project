
import React, { useState } from 'react';
import { User, Member, Transaction } from '../types';
import { UserPlus, Search, Phone, CreditCard, ExternalLink, Filter, X, History, TrendingUp } from 'lucide-react';

interface Props {
  user: User;
  members: Member[];
  addMember: (m: Member) => void;
  updateMember: (id: string, updates: Partial<Member>) => void;
  transactions: Transaction[];
  addTransaction: (t: Transaction) => void;
}

const MembershipManager: React.FC<Props> = ({ user, members, addMember, updateMember, transactions, addTransaction }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showRegModal, setShowRegModal] = useState(false);
  const [showTopUpModal, setShowTopUpModal] = useState<Member | null>(null);
  const [showHistoryModal, setShowHistoryModal] = useState<Member | null>(null);

  const [regData, setRegData] = useState({ name: '', phone: '', initialBalance: 0, discountRate: 5 });
  const [topUpAmount, setTopUpAmount] = useState(0);

  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    m.phone.includes(searchTerm)
  );

  const handleRegister = () => {
    if (!regData.name || !regData.phone) return;
    const newMember: Member = {
      id: Date.now().toString(),
      name: regData.name,
      phone: regData.phone,
      balance: regData.initialBalance,
      discountRate: regData.discountRate,
      registeredBy: user.name
    };
    addMember(newMember);
    if (regData.initialBalance > 0) {
      addTransaction({
        id: 'TX' + Date.now(),
        memberId: newMember.id,
        type: 'TOPUP',
        amount: regData.initialBalance,
        timestamp: new Date().toLocaleString(),
        description: 'Initial balance'
      });
    }
    setShowRegModal(false);
    setRegData({ name: '', phone: '', initialBalance: 0, discountRate: 5 });
  };

  const handleTopUp = () => {
    if (!showTopUpModal || topUpAmount <= 0) return;
    updateMember(showTopUpModal.id, { balance: showTopUpModal.balance + topUpAmount });
    addTransaction({
      id: 'TX' + Date.now(),
      memberId: showTopUpModal.id,
      type: 'TOPUP',
      amount: topUpAmount,
      timestamp: new Date().toLocaleString(),
      description: 'Account top up'
    });
    setShowTopUpModal(null);
    setTopUpAmount(0);
  };

  const getMemberTransactions = (id: string) => transactions.filter(t => t.memberId === id);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">Member Management</h2>
          <p className="text-gray-500 text-sm">Manage customers, balances and WhatsApp contacts</p>
        </div>
        <button 
          onClick={() => setShowRegModal(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-2xl font-bold shadow-xl shadow-indigo-600/20 flex items-center transition-all transform active:scale-[0.98]"
        >
          <UserPlus className="w-5 h-5 mr-2" />
          Register New Member
        </button>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search by name or phone..." 
            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="flex items-center px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50 text-gray-600 font-bold transition-colors">
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredMembers.map(member => (
          <div key={member.id} className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden hover:shadow-xl hover:border-indigo-200 transition-all group">
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center">
                  <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-2xl mr-4 shadow-lg shadow-indigo-600/20 group-hover:scale-110 transition-transform">
                    {member.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-lg font-black text-gray-900 leading-tight">{member.name}</h4>
                    <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest mt-0.5">ID: KBB-MB-{member.id.slice(-4)}</p>
                  </div>
                </div>
                <div className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100 shadow-sm shadow-emerald-100/50">
                  {member.discountRate}% Disc
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-center justify-between text-gray-600 bg-gray-50 p-3 rounded-2xl">
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 mr-3 text-gray-400" />
                    <span className="text-sm font-bold">+{member.phone}</span>
                  </div>
                  <a 
                    href={`https://wa.me/${member.phone}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="bg-white p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 shadow-sm transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
                <div className="flex items-center justify-between p-3 rounded-2xl bg-indigo-50/50">
                  <div className="flex items-center">
                    <CreditCard className="w-4 h-4 mr-3 text-indigo-400" />
                    <span className="text-sm text-indigo-900 font-medium">Balance</span>
                  </div>
                  <span className="text-lg font-black text-indigo-600 tracking-tighter">RM {member.balance.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => setShowTopUpModal(member)}
                  className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black transition-all shadow-lg shadow-indigo-600/10 active:scale-95 flex items-center justify-center uppercase tracking-widest"
                >
                  <TrendingUp className="w-3 h-3 mr-1.5" />
                  Top Up
                </button>
                <button 
                  onClick={() => setShowHistoryModal(member)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-black transition-all active:scale-95 flex items-center justify-center uppercase tracking-widest"
                >
                  <History className="w-3 h-3 mr-1.5" />
                  History
                </button>
              </div>
            </div>
            <div className="px-6 py-3 bg-gray-50 border-t border-gray-100 flex justify-between items-center">
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Added by</span>
              <span className="text-[10px] text-gray-600 font-black">{member.registeredBy}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Registration Modal */}
      {showRegModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white w-full max-w-md rounded-[40px] shadow-2xl overflow-hidden animate-scaleIn border border-gray-100">
            <div className="p-8 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black text-gray-900 tracking-tight">Register Member</h3>
                <p className="text-gray-500 text-sm font-medium">Create club account</p>
              </div>
              <button onClick={() => setShowRegModal(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <X className="w-6 h-6 text-gray-400" />
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Member Nickname</label>
                <input 
                  type="text" 
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-bold"
                  placeholder="e.g. Alvin"
                  value={regData.name}
                  onChange={e => setRegData({...regData, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">WhatsApp Number</label>
                <input 
                  type="tel" 
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-bold"
                  placeholder="60123456789"
                  value={regData.phone}
                  onChange={e => setRegData({...regData, phone: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Initial Balance</label>
                  <input 
                    type="number" 
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-bold"
                    placeholder="0.00"
                    value={regData.initialBalance}
                    onChange={e => setRegData({...regData, initialBalance: parseFloat(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Discount %</label>
                  <input 
                    type="number" 
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-bold"
                    placeholder="5"
                    value={regData.discountRate}
                    onChange={e => setRegData({...regData, discountRate: parseFloat(e.target.value) || 0})}
                  />
                </div>
              </div>
            </div>
            <div className="p-8 bg-gray-50 flex gap-4">
              <button 
                onClick={() => setShowRegModal(false)}
                className="flex-1 py-4 border border-gray-200 text-gray-600 font-bold rounded-2xl hover:bg-white transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleRegister}
                className="flex-1 py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-600/20 hover:bg-indigo-700 transition-all"
              >
                Register Account
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Up Modal */}
      {showTopUpModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white w-full max-w-sm rounded-[40px] shadow-2xl p-8 animate-scaleIn border border-gray-100">
            <h3 className="text-2xl font-black text-gray-900 mb-2">Top Up Account</h3>
            <p className="text-sm text-gray-500 mb-8 font-medium">Adding credit for <span className="text-indigo-600 font-black">{showTopUpModal.name}</span></p>
            
            <div className="mb-8">
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Top up Amount (RM)</label>
              <input 
                autoFocus
                type="number" 
                className="w-full px-6 py-5 bg-indigo-50 border-2 border-indigo-100 rounded-3xl outline-none focus:ring-2 focus:ring-indigo-500 text-3xl font-black text-indigo-600 text-center tracking-tighter transition-all"
                value={topUpAmount}
                onChange={e => setTopUpAmount(parseFloat(e.target.value) || 0)}
              />
              <div className="flex gap-2 mt-4">
                {[100, 500, 1000].map(amt => (
                  <button 
                    key={amt}
                    onClick={() => setTopUpAmount(amt)}
                    className="flex-1 py-2 bg-white border border-gray-200 rounded-xl text-xs font-bold hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-all"
                  >
                    +RM{amt}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => setShowTopUpModal(null)}
                className="flex-1 py-4 text-gray-500 font-bold rounded-2xl hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleTopUp}
                className="flex-1 py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-600/20 hover:bg-indigo-500 transition-all"
              >
                Add Credit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden animate-scaleIn border border-gray-100 flex flex-col max-h-[80vh]">
            <div className="p-8 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black text-gray-900 tracking-tight">Transaction History</h3>
                <p className="text-gray-500 text-sm font-medium">Account log for <span className="text-indigo-600 font-black">{showHistoryModal.name}</span></p>
              </div>
              <button onClick={() => setShowHistoryModal(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <X className="w-6 h-6 text-gray-400" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 space-y-4">
              {getMemberTransactions(showHistoryModal.id).length === 0 ? (
                <div className="py-20 text-center opacity-30 flex flex-col items-center">
                  <History className="w-16 h-16 mb-4" />
                  <p className="font-bold">No transactions found</p>
                </div>
              ) : (
                getMemberTransactions(showHistoryModal.id).map(tx => (
                  <div key={tx.id} className="bg-gray-50 p-4 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mr-4 ${tx.type === 'TOPUP' ? 'bg-emerald-100 text-emerald-600' : 'bg-indigo-100 text-indigo-600'}`}>
                        {tx.type === 'TOPUP' ? <TrendingUp className="w-5 h-5" /> : <CreditCard className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="text-sm font-black text-gray-800 uppercase tracking-tight">{tx.description}</p>
                        <p className="text-[10px] text-gray-400 font-bold">{tx.timestamp}</p>
                      </div>
                    </div>
                    <div className={`text-right font-black ${tx.type === 'TOPUP' ? 'text-emerald-600' : 'text-gray-800'}`}>
                      {tx.type === 'TOPUP' ? '+' : '-'} RM {tx.amount.toFixed(2)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MembershipManager;
