
import React, { useState } from 'react';
import { CreditCard, DollarSign, ListChecks, CheckCircle, AlertTriangle, FileText } from 'lucide-react';

const CashierPortal: React.FC = () => {
  const [dailyData, setDailyData] = useState({
    cash: 5240,
    creditCard: 6810,
    membershipTopUp: 3000,
    debt: 500,
  });

  const totalCalculated = dailyData.cash + dailyData.creditCard + dailyData.membershipTopUp;

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Daily Reconciliation</h2>
            <p className="text-gray-500 text-sm">Verify today's incoming payments across all channels</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400 font-bold uppercase mb-1">Total Received Today</p>
            <p className="text-3xl font-black text-indigo-600 underline">RM {totalCalculated.toFixed(2)}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 relative overflow-hidden">
            <DollarSign className="absolute -right-2 -bottom-2 w-16 h-16 text-emerald-200/50" />
            <p className="text-xs font-bold text-emerald-800 uppercase mb-1">Cash In Drawer</p>
            <div className="flex items-center">
              <span className="text-lg font-bold text-emerald-900 mr-2">RM</span>
              <input 
                type="number" 
                value={dailyData.cash}
                onChange={(e) => setDailyData({...dailyData, cash: parseFloat(e.target.value) || 0})}
                className="bg-white/50 border-emerald-200 rounded px-2 py-1 w-full text-lg font-bold outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 relative overflow-hidden">
            <CreditCard className="absolute -right-2 -bottom-2 w-16 h-16 text-blue-200/50" />
            <p className="text-xs font-bold text-blue-800 uppercase mb-1">Credit Card</p>
            <div className="flex items-center">
              <span className="text-lg font-bold text-blue-900 mr-2">RM</span>
              <input 
                type="number" 
                value={dailyData.creditCard}
                onChange={(e) => setDailyData({...dailyData, creditCard: parseFloat(e.target.value) || 0})}
                className="bg-white/50 border-blue-200 rounded px-2 py-1 w-full text-lg font-bold outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="p-4 bg-purple-50 rounded-xl border border-purple-100 relative overflow-hidden">
            <FileText className="absolute -right-2 -bottom-2 w-16 h-16 text-purple-200/50" />
            <p className="text-xs font-bold text-purple-800 uppercase mb-1">Membership Top-ups</p>
            <div className="flex items-center">
              <span className="text-lg font-bold text-purple-900 mr-2">RM</span>
              <input 
                type="number" 
                value={dailyData.membershipTopUp}
                onChange={(e) => setDailyData({...dailyData, membershipTopUp: parseFloat(e.target.value) || 0})}
                className="bg-white/50 border-purple-200 rounded px-2 py-1 w-full text-lg font-bold outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="p-4 bg-rose-50 rounded-xl border border-rose-100 relative overflow-hidden">
            <AlertTriangle className="absolute -right-2 -bottom-2 w-16 h-16 text-rose-200/50" />
            <p className="text-xs font-bold text-rose-800 uppercase mb-1">Outstanding Debt</p>
            <div className="flex items-center">
              <span className="text-lg font-bold text-rose-900 mr-2">RM</span>
              <input 
                type="number" 
                value={dailyData.debt}
                onChange={(e) => setDailyData({...dailyData, debt: parseFloat(e.target.value) || 0})}
                className="bg-white/50 border-rose-200 rounded px-2 py-1 w-full text-lg font-bold outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-xl shadow-lg shadow-indigo-100 flex items-center transition-all">
            <ListChecks className="w-5 h-5 mr-2" />
            Submit Daily Close
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 className="font-bold text-gray-800">Transaction Logs (Audit Trail)</h3>
            <span className="text-xs text-gray-400">Showing last 10 entries</span>
          </div>
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-50 text-gray-500 text-[10px] font-black uppercase tracking-widest">
              <tr>
                <th className="px-6 py-3">Time</th>
                <th className="px-6 py-3">Description</th>
                <th className="px-6 py-3">Payment</th>
                <th className="px-6 py-3 text-right">Amount</th>
                <th className="px-6 py-3 text-right">Uploaded By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-medium">
              {[1,2,3,4,5].map(i => (
                <tr key={i} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-gray-400">22:1{i}</td>
                  <td className="px-6 py-4 text-gray-800">Sales Entry - Table 0{i}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded text-[10px] uppercase font-bold">Credit</span>
                  </td>
                  <td className="px-6 py-4 text-right font-bold">RM {(250 * i).toFixed(2)}</td>
                  <td className="px-6 py-4 text-right text-indigo-600">Mei (Cashier)</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm h-fit">
          <h3 className="font-bold text-gray-800 mb-6 flex items-center">
            <CheckCircle className="w-5 h-5 mr-2 text-emerald-500" />
            Verification Status
          </h3>
          <div className="space-y-4">
            <div className="p-3 bg-emerald-50 rounded-lg flex items-center text-xs text-emerald-800">
              <div className="w-2 h-2 bg-emerald-500 rounded-full mr-3 animate-pulse"></div>
              Cash balance matched with system
            </div>
            <div className="p-3 bg-rose-50 rounded-lg flex items-center text-xs text-rose-800">
              <div className="w-2 h-2 bg-rose-500 rounded-full mr-3"></div>
              Credit card slip mismatch (-RM 12.00)
            </div>
            <div className="p-3 bg-amber-50 rounded-lg flex items-center text-xs text-amber-800">
              <div className="w-2 h-2 bg-amber-500 rounded-full mr-3"></div>
              Top-up RM3000 detected for member Alvin
            </div>
            <div className="mt-6 border-t border-gray-100 pt-6">
              <p className="text-xs text-gray-500 mb-4">Internal notes for Manager/Boss:</p>
              <textarea 
                className="w-full bg-gray-50 border border-gray-200 rounded-lg p-3 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                rows={4}
                placeholder="Any discrepancy notes..."
              ></textarea>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CashierPortal;
