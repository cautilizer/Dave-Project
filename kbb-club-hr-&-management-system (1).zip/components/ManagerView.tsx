
import React from 'react';
import { User, UserRole } from '../types';
import { Users, AlertCircle, Clock, ChevronRight } from 'lucide-react';

interface Props {
  user: User;
}

const ManagerView: React.FC<Props> = ({ user }) => {
  const subordinates = [
    { name: 'PR Crystal', status: 'Online', todaySales: 1200, checkIn: '20:00' },
    { name: 'PR Jessica', status: 'Online', todaySales: 850, checkIn: '20:15' },
    { name: 'PR Amanda', status: 'Offline', todaySales: 0, checkIn: '--:--' },
    { name: 'PR Bella', status: 'Online', todaySales: 2100, checkIn: '19:45' },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-100 mr-4">
            <Users className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Team Management</h2>
            <p className="text-gray-500 text-sm">Overseeing {subordinates.length} PR staff members</p>
          </div>
        </div>
        <div className="flex gap-2">
          <div className="text-right px-4 border-r border-gray-100">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Team Sales</p>
            <p className="text-xl font-black text-emerald-600">RM 4,150</p>
          </div>
          <div className="text-right px-4">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Active Now</p>
            <p className="text-xl font-black text-indigo-600">3 / 4</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-800">Staff Status & Performance</h3>
          <div className="flex items-center text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-full font-bold">
            <AlertCircle className="w-3 h-3 mr-1" />
            1 Staff Late
          </div>
        </div>
        <div className="divide-y divide-gray-100">
          {subordinates.map((staff, i) => (
            <div key={i} className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
              <div className="flex items-center flex-1">
                <div className="relative">
                  <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold mr-4">
                    {staff.name.charAt(3)}
                  </div>
                  <div className={`absolute bottom-0 right-4 w-3.5 h-3.5 border-2 border-white rounded-full ${
                    staff.status === 'Online' ? 'bg-emerald-500' : 'bg-gray-300'
                  }`}></div>
                </div>
                <div>
                  <h4 className="text-base font-bold text-gray-900">{staff.name}</h4>
                  <div className="flex items-center text-xs text-gray-400 mt-0.5">
                    <Clock className="w-3 h-3 mr-1" />
                    <span>Clock In: {staff.checkIn}</span>
                  </div>
                </div>
              </div>

              <div className="flex-1 px-8">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 text-center">Sales Generated</p>
                <div className="flex items-center justify-center">
                  <span className="text-sm font-black text-gray-800">RM {staff.todaySales}</span>
                  <div className="ml-3 w-32 h-2 bg-gray-100 rounded-full overflow-hidden hidden md:block">
                    <div 
                      className="bg-indigo-500 h-full rounded-full" 
                      style={{ width: `${Math.min((staff.todaySales / 2000) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center">
                <button className="px-4 py-2 text-xs font-bold text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors flex items-center">
                  View Detail
                  <ChevronRight className="w-4 h-4 ml-1" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ManagerView;
