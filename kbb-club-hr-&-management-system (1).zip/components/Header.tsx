
import React, { useState } from 'react';
import { User, Notification } from '../types';
import { Bell, Search, Settings, X, Check } from 'lucide-react';

interface HeaderProps {
  user: User;
  notifications: Notification[];
  setNotifications: React.Dispatch<React.SetStateAction<Notification[]>>;
}

const Header: React.FC<HeaderProps> = ({ user, notifications, setNotifications }) => {
  const [showNotif, setShowNotif] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-30 relative">
      <div className="flex items-center flex-1">
        <div className="relative w-64 mr-4 hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search records..." 
            className="w-full pl-10 pr-4 py-2 bg-gray-100 border-transparent rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
          />
        </div>
        <div className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold border border-indigo-100">
          KBB Branch #1
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <button 
          onClick={() => setShowNotif(!showNotif)}
          className={`p-2 rounded-full transition-colors relative ${showNotif ? 'bg-indigo-100 text-indigo-600' : 'text-gray-400 hover:bg-gray-100'}`}
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
          )}
        </button>
        <button 
          onClick={() => setShowSettings(!showSettings)}
          className={`p-2 rounded-full transition-colors ${showSettings ? 'bg-gray-100 text-indigo-600' : 'text-gray-400 hover:bg-gray-100'}`}
        >
          <Settings className="w-5 h-5" />
        </button>
        <div className="flex items-center pl-4 border-l border-gray-200">
          <div className="text-right mr-3 hidden md:block">
            <p className="text-sm font-semibold text-gray-900">{user.name}</p>
            <p className="text-xs text-gray-500 font-medium">{user.role}</p>
          </div>
          <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-100">
            {user.name.charAt(0)}
          </div>
        </div>
      </div>

      {/* Notifications Dropdown */}
      {showNotif && (
        <div className="absolute top-16 right-20 w-80 bg-white border border-gray-200 rounded-2xl shadow-2xl z-50 overflow-hidden">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
            <h4 className="font-bold text-gray-900">Notifications</h4>
            <button onClick={markAllRead} className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">Mark all read</button>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-10 text-center text-gray-400 text-sm">No new notifications</div>
            ) : (
              notifications.map(n => (
                <div key={n.id} className={`p-4 border-b border-gray-50 last:border-0 hover:bg-gray-50 transition-colors ${!n.read ? 'bg-indigo-50/30' : ''}`}>
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] font-black uppercase text-indigo-500 tracking-tighter">{n.type}</span>
                    <span className="text-[10px] text-gray-400">{n.time}</span>
                  </div>
                  <h5 className="text-sm font-bold text-gray-900">{n.title}</h5>
                  <p className="text-xs text-gray-500 mt-1">{n.message}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Settings Modal (Simplified) */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white w-full max-w-md rounded-[32px] p-8 shadow-2xl animate-scaleIn">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-black text-gray-900">Branch Settings</h3>
              <button onClick={() => setShowSettings(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Club Name</label>
                <input type="text" defaultValue="KBB CLUB BRANCH #1" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Operation Hours</label>
                <div className="grid grid-cols-2 gap-4">
                  <input type="time" defaultValue="20:00" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none" />
                  <input type="time" defaultValue="04:00" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none" />
                </div>
              </div>
              <div className="p-4 bg-indigo-50 rounded-2xl flex items-center text-indigo-700">
                <Check className="w-5 h-5 mr-3 shrink-0" />
                <p className="text-xs font-medium">Automatic daily closure is enabled for 04:30 AM.</p>
              </div>
              <button className="w-full bg-indigo-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-indigo-600/20 hover:bg-indigo-500 transition-all">
                SAVE CHANGES
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
