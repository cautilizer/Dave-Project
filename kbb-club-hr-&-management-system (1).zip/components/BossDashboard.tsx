
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, AreaChart, Area, Cell 
} from 'recharts';
import { TrendingUp, Users, DollarSign, AlertCircle } from 'lucide-react';

const BossDashboard: React.FC = () => {
  // Mock data matching requirements
  const stats = [
    { label: 'Total Sales Today', value: 'RM 12,450', icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Today\'s Clocked-In', value: '18 / 22', icon: ClockIcon, color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { label: 'Active Members', value: '342', icon: Users, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Outstanding Debt', value: 'RM 2,100', icon: AlertCircle, color: 'text-rose-600', bg: 'bg-rose-50' },
  ];

  const topPRs = [
    { name: 'PR Crystal', sales: 4500 },
    { name: 'PR Jessica', sales: 3800 },
    { name: 'PR Amanda', sales: 3200 },
    { name: 'PR Bella', sales: 2900 },
    { name: 'PR Sarah', sales: 1800 },
  ];

  const salesTrend = [
    { day: 'Mon', amount: 8500 },
    { day: 'Tue', amount: 9200 },
    { day: 'Wed', amount: 12000 },
    { day: 'Thu', amount: 10500 },
    { day: 'Fri', amount: 18000 },
    { day: 'Sat', amount: 22000 },
    { day: 'Sun', amount: 15000 },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex items-center hover:shadow-md transition-shadow">
            <div className={`${stat.bg} p-3 rounded-lg mr-4`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-900 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-indigo-500" />
              Weekly Sales Trend
            </h3>
            <select className="text-sm bg-gray-50 border-gray-200 rounded-md py-1 px-3 outline-none focus:ring-2 focus:ring-indigo-500">
              <option>This Week</option>
              <option>Last Week</option>
            </select>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={salesTrend}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="amount" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-amber-500" />
            Top 5 Performers
          </h3>
          <div className="space-y-4">
            {topPRs.map((pr, i) => (
              <div key={i} className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500 mr-3">
                  {i + 1}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-semibold text-gray-700">{pr.name}</span>
                    <span className="text-sm font-bold text-emerald-600">RM {pr.sales}</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className="bg-indigo-500 h-full rounded-full transition-all duration-1000" 
                      style={{ width: `${(pr.sales / topPRs[0].sales) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-2 text-sm font-semibold text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition-colors">
            View Full Report
          </button>
        </div>
      </div>
    </div>
  );
};

// Helper component
const ClockIcon = ({className}: {className?: string}) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export default BossDashboard;
