
import React, { useState } from 'react';
import { MenuItem, OrderItem, User, Table, Order } from '../types';
import { ShoppingCart, Plus, Minus, Search, Coffee, Beer, Utensils, Zap, LayoutGrid, CheckCircle } from 'lucide-react';

const MENU_ITEMS: MenuItem[] = [
  { id: '1', name: 'Tiger Beer Pint', price: 28.00, category: 'BEER' },
  { id: '2', name: 'Heineken Bottle', price: 32.00, category: 'BEER' },
  { id: '3', name: 'Black Label 750ml', price: 450.00, category: 'LIQUOR' },
  { id: '4', name: 'Hennessy VSOP', price: 580.00, category: 'LIQUOR' },
  { id: '5', name: 'Signature Fried Wings', price: 22.00, category: 'FOOD' },
  { id: '6', name: 'Truffle Fries', price: 18.00, category: 'SNACK' },
  { id: '7', name: 'Beef Nachos', price: 25.00, category: 'SNACK' },
  { id: '8', name: 'Chicken Skewers (6pcs)', price: 15.00, category: 'FOOD' },
];

interface Props {
  user: User;
  tables: Table[];
  placeOrder: (order: Order) => void;
}

const OrderSystem: React.FC<Props> = ({ user, tables, placeOrder }) => {
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<'ALL' | MenuItem['category']>('ALL');
  const [selectedTableId, setSelectedTableId] = useState<string>('');
  const [orderComplete, setOrderComplete] = useState(false);

  const filteredMenu = activeCategory === 'ALL' 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === activeCategory);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(oi => oi.menuItem.id === item.id);
      if (existing) {
        return prev.map(oi => oi.menuItem.id === item.id ? { ...oi, quantity: oi.quantity + 1 } : oi);
      }
      return [...prev, { menuItem: item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(oi => {
      if (oi.menuItem.id === id) {
        const newQty = Math.max(0, oi.quantity + delta);
        return { ...oi, quantity: newQty };
      }
      return oi;
    }).filter(oi => oi.quantity > 0));
  };

  const total = cart.reduce((sum, item) => sum + (item.menuItem.price * item.quantity), 0);

  const handlePlaceOrder = () => {
    if (!selectedTableId || cart.length === 0) return;
    
    const newOrder: Order = {
      id: 'ORD' + Date.now(),
      tableId: selectedTableId,
      items: cart,
      total: total,
      timestamp: new Date().toLocaleTimeString(),
      status: 'PENDING',
      orderedBy: user.name
    };

    placeOrder(newOrder);
    setCart([]);
    setOrderComplete(true);
    setTimeout(() => setOrderComplete(false), 3000);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full max-h-[85vh]">
      <div className="flex-1 flex flex-col gap-6 overflow-hidden">
        {/* Table Selector */}
        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
          <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Select Table First</label>
          <div className="flex flex-wrap gap-2">
            {tables.map(t => (
              <button
                key={t.id}
                onClick={() => setSelectedTableId(t.id)}
                className={`w-14 h-14 rounded-2xl font-black text-sm transition-all border flex flex-col items-center justify-center ${
                  selectedTableId === t.id 
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-600/30' 
                  : 'bg-white border-gray-100 text-gray-600 hover:border-indigo-200'
                }`}
              >
                {t.number}
                {t.status === 'OCCUPIED' && (
                  <span className="w-1 h-1 bg-red-400 rounded-full mt-0.5"></span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Category Selector */}
        <div className="bg-white p-4 rounded-3xl border border-gray-200 shadow-sm flex flex-wrap gap-2">
          {['ALL', 'BEER', 'LIQUOR', 'FOOD', 'SNACK'].map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat as any)}
              className={`px-6 py-2.5 rounded-2xl text-xs font-black transition-all uppercase tracking-widest ${
                activeCategory === cat 
                ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/20' 
                : 'bg-gray-50 text-gray-400 hover:bg-gray-100 border border-gray-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 overflow-y-auto pb-4 pr-2 scrollbar-thin">
          {filteredMenu.map(item => (
            <button
              key={item.id}
              onClick={() => addToCart(item)}
              className="bg-white p-5 rounded-[32px] border border-gray-200 shadow-sm hover:shadow-xl hover:border-indigo-200 transition-all text-left flex flex-col h-full group"
            >
              <div className="mb-4 bg-gray-50 rounded-2xl aspect-square flex items-center justify-center text-gray-300 group-hover:text-indigo-400 transition-colors">
                {item.category === 'BEER' && <Beer className="w-12 h-12" />}
                {item.category === 'LIQUOR' && <Zap className="w-12 h-12" />}
                {item.category === 'FOOD' && <Utensils className="w-12 h-12" />}
                {item.category === 'SNACK' && <Coffee className="w-12 h-12" />}
              </div>
              <p className="text-sm font-black text-gray-900 leading-tight mb-2 h-10 line-clamp-2">{item.name}</p>
              <p className="mt-auto text-indigo-600 font-black tracking-tighter">RM {item.price.toFixed(2)}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="w-full lg:w-96 bg-white rounded-[40px] border border-gray-200 shadow-2xl flex flex-col overflow-hidden">
        <div className="p-8 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div>
            <h3 className="font-black text-gray-900 flex items-center tracking-tight">
              <ShoppingCart className="w-5 h-5 mr-3 text-indigo-600" />
              ORDER LIST
            </h3>
            {selectedTableId && (
              <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mt-1">
                FOR TABLE: {tables.find(t => t.id === selectedTableId)?.number}
              </p>
            )}
          </div>
          <span className="bg-slate-900 text-white text-[10px] px-3 py-1 rounded-full font-black">
            {cart.reduce((s, i) => s + i.quantity, 0)} ITEMS
          </span>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {orderComplete ? (
            <div className="h-full flex flex-col items-center justify-center text-center animate-fadeIn">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="w-8 h-8" />
              </div>
              <p className="font-black text-emerald-900">ORDER PLACED!</p>
              <p className="text-xs text-gray-500 mt-1">Sent to Bar & Kitchen</p>
            </div>
          ) : cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
              <ShoppingCart className="w-16 h-16 mb-2" />
              <p className="font-bold">No items added</p>
            </div>
          ) : (
            cart.map(oi => (
              <div key={oi.menuItem.id} className="bg-slate-50 p-4 rounded-3xl flex items-center gap-4 group">
                <div className="flex-1">
                  <p className="text-sm font-black text-gray-800 leading-tight">{oi.menuItem.name}</p>
                  <p className="text-xs text-indigo-600 font-black mt-1 tracking-tight">RM {(oi.menuItem.price * oi.quantity).toFixed(2)}</p>
                </div>
                <div className="flex items-center gap-3 bg-white rounded-2xl border border-gray-100 p-1.5 shadow-sm">
                  <button 
                    onClick={() => updateQuantity(oi.menuItem.id, -1)}
                    className="p-1.5 hover:bg-gray-50 rounded-xl text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-xs font-black w-4 text-center">{oi.quantity}</span>
                  <button 
                    onClick={() => updateQuantity(oi.menuItem.id, 1)}
                    className="p-1.5 hover:bg-gray-50 rounded-xl text-indigo-600"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-8 bg-slate-900 text-white rounded-t-[40px] shadow-2xl">
          <div className="flex justify-between items-center mb-8">
            <span className="text-slate-400 text-sm font-bold uppercase tracking-widest">Total Bill</span>
            <span className="text-4xl font-black tracking-tighter">RM {total.toFixed(2)}</span>
          </div>
          <button 
            disabled={!selectedTableId || cart.length === 0}
            onClick={handlePlaceOrder}
            className={`w-full py-5 rounded-2xl font-black text-lg transition-all shadow-xl flex items-center justify-center gap-3 ${
              !selectedTableId || cart.length === 0
              ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
              : 'bg-indigo-600 text-white shadow-indigo-600/20 hover:bg-indigo-500 transform active:scale-[0.98]'
            }`}
          >
            {!selectedTableId ? 'SELECT TABLE' : 'CONFIRM ORDER'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderSystem;
