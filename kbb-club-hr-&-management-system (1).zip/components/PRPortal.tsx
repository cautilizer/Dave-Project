
import React, { useState } from 'react';
import { User, Sale } from '../types';
import { TrendingUp, Award, Calendar, ChevronRight, Gift, Wallet } from 'lucide-react';

interface Props {
  user: User;
}

const PRPortal: React.FC<Props> = ({ user }) => {
  const [sales] = useState<Sale[]>([
    { id: '1', prId: user.id, customerId: 'm1', amount: 1500, giftValue: 200, paymentMethod: 'CASH', timestamp: '2023-11-23 21:00', uploadedBy: 'cashier1' },
    { id: '2', prId: user.id, customerId: 'm2', amount: 2000, giftValue: 500, paymentMethod: 'CREDIT', timestamp: '2023-11-23 23:30', uploadedBy: 'cashier1' },
    { id: '3', prId: user.id, customerId: 'm3', amount: 800, giftValue: 100, paymentMethod: 'DEBT', timestamp: '2023-11-24 01:15', uploadedBy: 'cashier1' },
  ]);

  const totalSales = sales.reduce((sum, s) => sum + s.amount, 0);
  const totalCommission = (totalSales * user.commissionRate) / 100;
  const totalGifts = sales.reduce((sum, s) => sum + s.giftValue, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-indigo-600 p-6 rounded-2xl text-white shadow-xl shadow-indigo-200 relative overflow-hidden">
          <TrendingUp className="absolute top-[-10px] right-[-10px] w-32 h-32 opacity-10" />
          <p className="text-indigo-100 text-xs font-bold uppercase tracking-widest mb-1">Weekly Forecast</p>
          <p className="text-4xl font-black">RM {totalCommission + user.baseSalary}</p>
          <div className="mt-4 flex items-center text-xs bg-indigo-500/30 w-fit px-2 py-1 rounded">
            <Award className="w-3 h-3 mr-1" />
            <span>Commission: {user.commissionRate}%</span>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center text-emerald-600 mb-2">
            <Wallet className="w-5 h-5 mr-2" />
            <span className="text-xs font-bold uppercase tracking-widest">Total Sales Generated</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">RM {totalSales}</p>
          <p className="text-xs text-gray-500 mt-2 font-medium">Calculated from {sales.length} transactions</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center text-amber-600 mb-2">
            <Gift className="w-5 h-5 mr-2" />
            <span className="text-xs font-bold uppercase tracking-widest">Customer Gifts (Virtual)</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">RM {totalGifts}</p>
          <p className="text-xs text-gray-500 mt-2 font-medium">Extra incentives earned tonight</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 className="font-bold text-gray-800 flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-indigo-500" />
              Work History
            </h3>
            <button className="text-xs font-bold text-indigo-600 hover:underline">View All</button>
          </div>
          <div className="divide-y divide-gray-100">
            {sales.map((sale, i) => (
              <div key={sale.id} className="p-4 hover:bg-gray-50 transition-colors flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 mr-4">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-800">Sales Record #{sale.id.slice(0, 5)}</p>
                    <p className="text-xs text-gray-400">{sale.timestamp}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-gray-900">RM {sale.amount}</p>
                  <p className={`text-[10px] font-black uppercase tracking-tighter ${
                    sale.paymentMethod === 'DEBT' ? 'text-rose-500' : 'text-emerald-500'
                  }`}>{sale.paymentMethod}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="font-bold text-gray-800 mb-6">Earnings Breakdown (Weekly Template)</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-gray-50">
              <span className="text-sm text-gray-600">Base Weekly Pay</span>
              <span className="text-sm font-bold text-gray-900">RM {user.baseSalary}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-50">
              <span className="text-sm text-gray-600">Commission ({user.commissionRate}%)</span>
              <span className="text-sm font-bold text-gray-900">RM {totalCommission}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-50">
              <span className="text-sm text-gray-600">Attendance Bonus</span>
              <span className="text-sm font-bold text-emerald-600">+ RM 50.00</span>
            </div>
            <div className="flex justify-between items-center pt-4">
              <span className="text-base font-bold text-gray-900">Net Payout</span>
              <span className="text-xl font-black text-indigo-600 underline">RM {totalCommission + user.baseSalary + 50}</span>
            </div>
            <div className="mt-6 p-4 bg-amber-50 rounded-lg text-amber-800 text-xs">
              <strong>Note:</strong> Weekly payments are processed every Monday. Debts from customers are deducted from final payout if unpaid after 7 days.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PRPortal;
