
import React, { useState, useEffect } from 'react';
import { User, Attendance } from '../types';
import { MapPin, CheckCircle, XCircle, Clock } from 'lucide-react';

interface Props {
  user: User;
}

const AttendanceTracker: React.FC<Props> = ({ user }) => {
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [status, setStatus] = useState<'IDLE' | 'CHECKED_IN' | 'CHECKED_OUT'>('IDLE');
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<Attendance[]>([]);

  useEffect(() => {
    // Initial fetch of attendance history
    const mockHistory: Attendance[] = [
      { id: '1', userId: user.id, date: '2023-11-20', checkIn: '20:00', checkOut: '03:30', location: {lat: 3.139, lng: 101.686} },
      { id: '2', userId: user.id, date: '2023-11-21', checkIn: '20:15', checkOut: '04:00', location: {lat: 3.139, lng: 101.686} },
    ];
    setHistory(mockHistory);
  }, [user.id]);

  const handleCheckIn = () => {
    setError(null);
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const loc = { lat: position.coords.latitude, lng: position.coords.longitude };
        setLocation(loc);
        setStatus('CHECKED_IN');
        // In a real app, API call here
      },
      (err) => {
        setError(`Unable to retrieve location: ${err.message}. Location is required for check-in.`);
      }
    );
  };

  const handleCheckOut = () => {
    setStatus('CHECKED_OUT');
    // Logic as per prompt: check out is optional ("maybe drunk"), but we provide the button.
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-xl text-center">
        <div className="mb-6">
          <div className="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Clock className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Attendance Center</h2>
          <p className="text-gray-500 mt-1">Check-in at the club premises to start your shift</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-700 p-4 rounded-lg mb-6 flex items-start text-left border border-red-100">
            <AlertCircle className="w-5 h-5 mr-3 shrink-0" />
            <span className="text-sm font-medium">{error}</span>
          </div>
        )}

        <div className="space-y-4">
          {status === 'IDLE' && (
            <button 
              onClick={handleCheckIn}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-200 transition-all flex items-center justify-center"
            >
              <MapPin className="w-6 h-6 mr-2" />
              Check In Now
            </button>
          )}

          {status === 'CHECKED_IN' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 text-emerald-700 p-6 rounded-xl border border-emerald-100">
                <div className="flex items-center justify-center mb-2">
                  <CheckCircle className="w-8 h-8 mr-2" />
                  <span className="text-xl font-bold">Successfully Checked In</span>
                </div>
                <p className="text-sm opacity-90">Location Verified: {location?.lat.toFixed(4)}, {location?.lng.toFixed(4)}</p>
                <p className="text-sm mt-2 font-mono">Time: {new Date().toLocaleTimeString()}</p>
              </div>
              <button 
                onClick={handleCheckOut}
                className="w-full py-3 border-2 border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl font-semibold transition-colors"
              >
                End Shift (Check Out)
              </button>
            </div>
          )}

          {status === 'CHECKED_OUT' && (
            <div className="bg-slate-50 text-slate-600 p-6 rounded-xl border border-slate-200">
              <p className="text-lg font-bold">Shift Completed</p>
              <p className="text-sm">Great work tonight! See you next time.</p>
              <button 
                onClick={() => setStatus('IDLE')}
                className="mt-4 text-indigo-600 text-sm font-bold hover:underline"
              >
                Reset for new shift
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
          <h3 className="font-bold text-gray-800">Recent History</h3>
        </div>
        <div className="divide-y divide-gray-100">
          {history.length === 0 ? (
            <div className="p-10 text-center text-gray-400">No recent activity</div>
          ) : (
            history.map(item => (
              <div key={item.id} className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center mr-4">
                    <Clock className="w-5 h-5 text-slate-500" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-800">{item.date}</p>
                    <p className="text-xs text-gray-500">Verified at KBB Club</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-gray-700">{item.checkIn} - {item.checkOut || 'N/A'}</p>
                  <span className="text-[10px] bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full font-bold uppercase tracking-tight">Verified</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

const AlertCircle = ({className}: {className?: string}) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export default AttendanceTracker;
