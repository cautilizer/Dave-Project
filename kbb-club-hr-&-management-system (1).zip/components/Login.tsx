
import React, { useState } from 'react';
import { UserRole, User } from '../types';
import { ShieldCheck, Lock, User as UserIcon, AlertCircle, Info } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

// Hardcoded demo credentials for each role
const DEMO_CREDENTIALS: Record<string, { role: UserRole, pass: string, name: string }> = {
  'boss01': { role: UserRole.BOSS, pass: 'boss123', name: 'Boss Chen' },
  'manager01': { role: UserRole.MANAGER, pass: 'manager123', name: 'Manager Wong' },
  'pr01': { role: UserRole.PR, pass: 'pr123', name: 'PR Crystal' },
  'cashier01': { role: UserRole.CASHIER, pass: 'cashier123', name: 'Cashier Mei' },
};

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [showDemoInfo, setShowDemoInfo] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cred = DEMO_CREDENTIALS[userId.toLowerCase()];

    if (cred && cred.pass === password) {
      const mockUser: User = {
        id: userId,
        name: cred.name,
        role: cred.role,
        commissionRate: cred.role === UserRole.PR ? 15 : 0,
        baseSalary: cred.role === UserRole.PR ? 800 : 2500
      };
      onLogin(mockUser);
    } else {
      setError('Invalid Employee ID or Passcode. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/20 rounded-full blur-[120px]"></div>

      <div className="w-full max-w-md z-10">
        <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-8 rounded-3xl shadow-2xl">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-indigo-600 shadow-lg shadow-indigo-500/20 mb-6">
              <ShieldCheck className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-black text-white tracking-tight">KBB CLUB</h1>
            <p className="text-slate-400 mt-2 font-medium">Enterprise HR & Management System</p>
          </div>

          {error && (
            <div className="mb-6 bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl flex items-start text-sm animate-pulse">
              <AlertCircle className="w-5 h-5 mr-3 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-6">
            <div className="space-y-4">
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Employee ID"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl py-4 pl-12 pr-4 text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  required
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input 
                  type="password" 
                  placeholder="Passcode"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl py-4 pl-12 pr-4 text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  required
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-xl shadow-xl shadow-indigo-600/20 transition-all transform active:scale-[0.98] mt-4"
            >
              SECURE LOGIN
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-700/50">
            <button 
              onClick={() => setShowDemoInfo(!showDemoInfo)}
              className="flex items-center justify-center w-full text-slate-500 hover:text-indigo-400 text-xs font-bold transition-colors"
            >
              <Info className="w-4 h-4 mr-2" />
              {showDemoInfo ? 'HIDE DEMO ACCOUNTS' : 'SHOW DEMO ACCOUNTS'}
            </button>
            
            {showDemoInfo && (
              <div className="mt-4 grid grid-cols-2 gap-2 text-[10px] text-slate-400 bg-slate-900/50 p-3 rounded-xl border border-slate-700/30">
                <div><strong>BOSS:</strong> boss01 / boss123</div>
                <div><strong>MANAGER:</strong> manager01 / manager123</div>
                <div><strong>PR:</strong> pr01 / pr123</div>
                <div><strong>CASHIER:</strong> cashier01 / cashier123</div>
              </div>
            )}
          </div>

          <p className="text-center text-slate-500 text-[10px] mt-8 font-medium uppercase tracking-widest">
            KBB Branch Security Standard #2401
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
