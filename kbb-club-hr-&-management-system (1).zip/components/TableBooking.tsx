import React, { useState } from 'react';
import { Table, User, Order, Member } from '../types';
import { Calendar, Users, MapPin, CheckCircle2, History, X, UserPlus, Search } from 'lucide-react';

interface Props {
  user: User;
  tables: Table[];
  setTables: React.Dispatch<React.SetStateAction<Table[]>>;
  orders: Order[];
  members: Member[];
}

const TableBooking: React.FC<Props> = ({ user, tables, setTables, orders, members }) => {
  const [selectedTableId, setSelectedTableId] = useState<string | null>(null);
  const [showOrdersModal, setShowOrdersModal] = useState(false);
  const [showMemberSelectModal, setShowMemberSelectModal] = useState(false);
  const [memberSearchTerm, setMemberSearchTerm] = useState('');

  // Explicitly finding the selected table from the current tables prop to ensure reactivity
  const selectedTable = tables.find(t => t.id === selectedTableId) || null;

  const handleTableAction = (id: string) => {
    setTables(prev => prev.map(t => {
      if (t.id === id) {
        // Toggle status: if RESERVED or OCCUPIED -> AVAILABLE, else -> RESERVED (generic)
        const isOccupiedOrReserved = t.status === 'RESERVED' || t.status === 'OCCUPIED';
        const nextStatus: Table['status'] = isOccupiedOrReserved ? 'AVAILABLE' : 'RESERVED';
        
        return { 
          ...t, 
          status: nextStatus,
          assignedMemberId: nextStatus === 'AVAILABLE' ? undefined : t.assignedMemberId
        };
      }
      return t;
    }));
  };

  const assignMemberToTable = (member: Member) => {
    if (!selectedTableId) return;
    setTables(prev => prev.map(t => {
      if (t.id === selectedTableId) {
        return {
          ...t,
          status: 'RESERVED',
          assignedMemberId: member.name
        };
      }
      return t;
    }));
    setShowMemberSelectModal(false);
    setMemberSearchTerm('');
  };

  const getTableOrders = (id: string) => orders.filter(o => o.tableId === id);

  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(memberSearchTerm.toLowerCase()) ||
    m.phone.includes(memberSearchTerm)
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">Digital Floor Plan</h2>
          <p className="text-gray-500 text-sm">Real-time table occupancy and seat booking</p>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-100 text-[10px] font-black uppercase tracking-widest shadow-sm">
            <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></div> Available
          </div>
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-100 text-[10px] font-black uppercase tracking-widest shadow-sm">
            <div className="w-2.5 h-2.5 bg-amber-500 rounded-full"></div> Reserved
          </div>
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-100 text-[10px] font-black uppercase tracking-widest shadow-sm">
            <div className="w-2.5 h-2.5 bg-rose-500 rounded-full"></div> Occupied
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 bg-slate-100 p-8 rounded-[48px] border border-slate-200 shadow-inner min-h-[600px] flex items-center justify-center">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-8">
            {tables.map(table => (
              <button
                key={table.id}
                onClick={() => setSelectedTableId(table.id)}
                className={`aspect-square w-24 md:w-32 rounded-[32px] p-4 flex flex-col items-center justify-center transition-all border-4 shadow-xl ${
                  selectedTableId === table.id ? 'scale-110 border-indigo-600 ring-4 ring-indigo-100 z-10' : 'border-transparent ring-0'
                } ${
                  table.status === 'AVAILABLE' ? 'bg-white text-gray-800' : 
                  table.status === 'RESERVED' ? 'bg-amber-500 text-white' : 
                  'bg-rose-500 text-white'
                }`}
              >
                <p className="text-2xl font-black mb-1 leading-none">{table.number}</p>
                <div className="flex items-center gap-1 opacity-60">
                  <Users className="w-3 h-3" />
                  <span className="text-[10px] font-bold">{table.capacity}</span>
                </div>
                {table.assignedMemberId && (
                  <div className="mt-1 text-[8px] font-black truncate max-w-full px-2 py-0.5 bg-white/20 rounded">
                    {table.assignedMemberId}
                  </div>
                )}
                <div className="mt-2 text-[8px] font-black uppercase tracking-tighter bg-black/10 px-2 py-0.5 rounded-full">
                  {table.type}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-[48px] border border-gray-200 shadow-2xl p-10 sticky top-6 h-fit min-h-[500px] flex flex-col">
          {selectedTable ? (
            <div className="space-y-8 flex-1 flex flex-col animate-fadeIn">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-4xl font-black text-gray-900 leading-none tracking-tighter">{selectedTable.number}</h3>
                  <p className="text-indigo-600 text-[10px] font-black uppercase tracking-[0.2em] mt-3">{selectedTable.type} ZONE</p>
                </div>
                <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm ${
                  selectedTable.status === 'AVAILABLE' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 
                  selectedTable.status === 'RESERVED' ? 'bg-amber-50 text-amber-600 border border-amber-100' :
                  'bg-rose-50 text-rose-600 border border-rose-100'
                }`}>
                  {selectedTable.status}
                </div>
              </div>

              <div className="space-y-6 pt-8 border-t border-gray-100">
                <div className="flex items-center text-gray-500 font-bold text-sm">
                  <MapPin className="w-5 h-5 mr-4 text-indigo-400" />
                  Main Hall, Row {selectedTable.number.charAt(0)}
                </div>
                <div className="flex items-center text-gray-500 font-bold text-sm">
                  <Users className="w-5 h-5 mr-4 text-indigo-400" />
                  Capacity: {selectedTable.capacity} Seats
                </div>
                {selectedTable.assignedMemberId && (
                  <div className="flex items-center text-indigo-900 bg-indigo-50 p-4 rounded-2xl border border-indigo-100 animate-fadeIn">
                    <CheckCircle2 className="w-5 h-5 mr-3 text-indigo-600" />
                    <div>
                      <p className="text-[10px] font-black uppercase text-indigo-400 tracking-widest">Reserved For</p>
                      <p className="text-sm font-black">{selectedTable.assignedMemberId}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-10 space-y-4 mt-auto">
                {selectedTable.status === 'AVAILABLE' ? (
                  <>
                    <button 
                      onClick={() => setShowMemberSelectModal(true)}
                      className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-black text-sm hover:bg-indigo-500 transform active:scale-95 shadow-xl shadow-indigo-600/20 uppercase tracking-widest flex items-center justify-center gap-2"
                    >
                      <UserPlus className="w-4 h-4" />
                      Reserve for Member
                    </button>
                    <button 
                      onClick={() => handleTableAction(selectedTable.id)}
                      className="w-full py-5 bg-slate-100 text-slate-700 rounded-3xl font-black text-sm hover:bg-slate-200 transform active:scale-95 uppercase tracking-widest"
                    >
                      Quick Reserve
                    </button>
                  </>
                ) : (
                  <button 
                    onClick={() => handleTableAction(selectedTable.id)}
                    className="w-full py-5 bg-rose-600 text-white rounded-3xl font-black text-sm hover:bg-rose-500 transform active:scale-95 shadow-xl shadow-rose-600/20 uppercase tracking-widest"
                  >
                    Release Table
                  </button>
                )}
                
                <button 
                  onClick={() => setShowOrdersModal(true)}
                  className="w-full py-5 bg-gray-50 text-gray-600 rounded-3xl font-black text-sm hover:bg-gray-100 transition-all uppercase tracking-widest flex items-center justify-center gap-2 border border-gray-100"
                >
                  <History className="w-4 h-4" />
                  Table Orders
                </button>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center opacity-30">
              <Calendar className="w-20 h-20 mb-6 text-gray-400" />
              <p className="font-black text-lg tracking-tight">SELECT TABLE</p>
              <p className="text-sm font-medium px-10 mt-2 leading-relaxed">Choose a table from the floor plan to manage occupancy</p>
            </div>
          )}
        </div>
      </div>

      {/* Member Selection Modal */}
      {showMemberSelectModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[110] p-4">
          <div className="bg-white w-full max-w-md rounded-[40px] shadow-2xl overflow-hidden animate-scaleIn flex flex-col max-h-[80vh]">
            <div className="p-8 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black text-gray-900 tracking-tight">Select Member</h3>
                <p className="text-gray-500 text-sm font-medium">Assign reservation to customer</p>
              </div>
              <button onClick={() => setShowMemberSelectModal(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <X className="w-6 h-6 text-gray-400" />
              </button>
            </div>
            
            <div className="p-6 bg-gray-50/50 border-b border-gray-100">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input 
                  type="text" 
                  placeholder="Search by name or phone..." 
                  className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                  value={memberSearchTerm}
                  onChange={(e) => setMemberSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {filteredMembers.length === 0 ? (
                <div className="py-20 text-center text-gray-400 font-bold">No members found</div>
              ) : (
                filteredMembers.map(member => (
                  <button 
                    key={member.id}
                    onClick={() => assignMemberToTable(member)}
                    className="w-full p-4 flex items-center justify-between bg-white border border-gray-100 rounded-2xl hover:border-indigo-500 hover:shadow-md transition-all group"
                  >
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center font-black mr-4 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                        {member.name.charAt(0)}
                      </div>
                      <div className="text-left">
                        <p className="font-black text-gray-900">{member.name}</p>
                        <p className="text-xs text-gray-400">+{member.phone}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-black uppercase text-indigo-600 tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Select Member</span>
                  </button>
                ))
              )}
            </div>
            
            <div className="p-6 bg-gray-50 text-center">
              <button onClick={() => setShowMemberSelectModal(false)} className="text-sm font-bold text-gray-500 hover:text-gray-700">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Table Orders Modal */}
      {showOrdersModal && selectedTable && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white w-full max-w-2xl rounded-[48px] shadow-2xl overflow-hidden animate-scaleIn flex flex-col max-h-[85vh]">
            <div className="p-10 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h3 className="text-3xl font-black text-gray-900 tracking-tighter">Order History</h3>
                <p className="text-indigo-600 text-xs font-black uppercase tracking-widest mt-2">TABLE {selectedTable.number}</p>
              </div>
              <button onClick={() => setShowOrdersModal(false)} className="p-3 hover:bg-gray-100 rounded-full transition-colors">
                <X className="w-8 h-8 text-gray-400" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-10 space-y-6">
              {getTableOrders(selectedTable.id).length === 0 ? (
                <div className="py-20 text-center opacity-20 flex flex-col items-center">
                  <History className="w-16 h-16 mb-4" />
                  <p className="font-black text-lg uppercase tracking-widest">No Active Orders</p>
                </div>
              ) : (
                getTableOrders(selectedTable.id).map(order => (
                  <div key={order.id} className="bg-slate-50 p-6 rounded-[32px] border border-gray-100">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Order ID: {order.id}</p>
                        <p className="text-lg font-black text-gray-900 mt-1">{order.timestamp}</p>
                      </div>
                      <div className="bg-white px-4 py-1.5 rounded-full border border-gray-200 text-[10px] font-black text-indigo-600 uppercase tracking-widest shadow-sm">
                        {order.status}
                      </div>
                    </div>
                    <div className="space-y-2 mb-6">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-sm font-bold text-gray-600">
                          <span>{item.quantity}x {item.menuItem.name}</span>
                          <span className="text-gray-400">RM {(item.menuItem.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between items-center pt-4 border-t border-gray-200/50">
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Ordered By: <span className="text-indigo-600">{order.orderedBy}</span></p>
                      <p className="text-xl font-black text-indigo-600">RM {order.total.toFixed(2)}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TableBooking;