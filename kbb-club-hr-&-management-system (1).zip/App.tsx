
import React, { useState, useEffect } from 'react';
import { UserRole, User, Member, Table, Order, Transaction, Notification } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import BossDashboard from './components/BossDashboard';
import PRPortal from './components/PRPortal';
import ManagerView from './components/ManagerView';
import CashierPortal from './components/CashierPortal';
import AttendanceTracker from './components/AttendanceTracker';
import MembershipManager from './components/MembershipManager';
import OrderSystem from './components/OrderSystem';
import TableBooking from './components/TableBooking';
import Login from './components/Login';

const INITIAL_TABLES: Table[] = [
  { id: 'v1', number: 'V01', type: 'VIP', status: 'AVAILABLE', capacity: 8 },
  { id: 'v2', number: 'V02', type: 'VIP', status: 'RESERVED', capacity: 8, assignedMemberId: 'Alvin' },
  { id: 'v3', number: 'V03', type: 'VIP', status: 'AVAILABLE', capacity: 12 },
  { id: 'r1', number: 'T01', type: 'REGULAR', status: 'OCCUPIED', capacity: 4 },
  { id: 'r2', number: 'T02', type: 'REGULAR', status: 'AVAILABLE', capacity: 4 },
  { id: 'r3', number: 'T03', type: 'REGULAR', status: 'AVAILABLE', capacity: 4 },
  { id: 'r4', number: 'T04', type: 'REGULAR', status: 'AVAILABLE', capacity: 4 },
  { id: 'b1', number: 'B01', type: 'BAR', status: 'AVAILABLE', capacity: 1 },
  { id: 'b2', number: 'B02', type: 'BAR', status: 'OCCUPIED', capacity: 1 },
];

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  // Persistence logic (Simulation of database)
  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem('kbb_members');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Alvin', phone: '60123456789', balance: 2500, discountRate: 10, registeredBy: 'PR Crystal' },
      { id: '2', name: 'Tan K.H.', phone: '60128889999', balance: 150.50, discountRate: 5, registeredBy: 'PR Amanda' }
    ];
  });

  const [tables, setTables] = useState<Table[]>(() => {
    const saved = localStorage.getItem('kbb_tables');
    return saved ? JSON.parse(saved) : INITIAL_TABLES;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('kbb_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('kbb_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [notifications, setNotifications] = useState<Notification[]>([
    { id: '1', title: 'New Registration', message: 'Alvin has joined as a VIP member.', time: '2h ago', read: false, type: 'SYSTEM' },
    { id: '2', title: 'Large Order', message: 'Table V03 just ordered 5 Tiger Beer Pints.', time: '10m ago', read: false, type: 'ORDER' }
  ]);

  useEffect(() => {
    localStorage.setItem('kbb_members', JSON.stringify(members));
    localStorage.setItem('kbb_tables', JSON.stringify(tables));
    localStorage.setItem('kbb_orders', JSON.stringify(orders));
    localStorage.setItem('kbb_transactions', JSON.stringify(transactions));
  }, [members, tables, orders, transactions]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsLoggedIn(true);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
  };

  // Shared Actions
  const addMember = (m: Member) => setMembers([...members, m]);
  const updateMember = (id: string, updates: Partial<Member>) => {
    setMembers(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));
  };

  const addTransaction = (t: Transaction) => setTransactions([t, ...transactions]);

  const placeOrder = (order: Order) => {
    setOrders([order, ...orders]);
    // Update table status to Occupied if it was Available
    setTables(prev => prev.map(t => 
      t.id === order.tableId && t.status === 'AVAILABLE' ? { ...t, status: 'OCCUPIED' } : t
    ));
    // Add a notification
    const newNotif: Notification = {
      id: Date.now().toString(),
      title: 'New Order',
      message: `Table ${tables.find(t => t.id === order.tableId)?.number} placed an order of RM${order.total}`,
      time: 'Just now',
      read: false,
      type: 'ORDER'
    };
    setNotifications([newNotif, ...notifications]);
  };

  if (!isLoggedIn || !currentUser) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        if (currentUser.role === UserRole.BOSS) return <BossDashboard />;
        if (currentUser.role === UserRole.MANAGER) return <ManagerView user={currentUser} />;
        if (currentUser.role === UserRole.PR) return <PRPortal user={currentUser} />;
        if (currentUser.role === UserRole.CASHIER) return <CashierPortal />;
        return <BossDashboard />;
      case 'pos':
        return <OrderSystem user={currentUser} tables={tables} placeOrder={placeOrder} />;
      case 'booking':
        return <TableBooking user={currentUser} tables={tables} setTables={setTables} orders={orders} members={members} />;
      case 'attendance':
        return <AttendanceTracker user={currentUser} />;
      case 'membership':
        return (
          <MembershipManager 
            user={currentUser} 
            members={members} 
            addMember={addMember} 
            updateMember={updateMember}
            transactions={transactions}
            addTransaction={addTransaction}
          />
        );
      case 'cashier':
        return <CashierPortal />;
      default:
        return <BossDashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100 font-sans">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        role={currentUser.role} 
        onLogout={handleLogout}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          user={currentUser} 
          notifications={notifications} 
          setNotifications={setNotifications} 
        />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-slate-50">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
