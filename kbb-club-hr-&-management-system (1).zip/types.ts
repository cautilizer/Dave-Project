
export enum UserRole {
  BOSS = 'BOSS',
  MANAGER = 'MANAGER',
  PR = 'PR',
  CASHIER = 'CASHIER'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  managerId?: string;
  commissionRate: number;
  baseSalary: number;
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: 'FOOD' | 'BEER' | 'LIQUOR' | 'SNACK';
  image?: string;
}

export interface OrderItem {
  menuItem: MenuItem;
  quantity: number;
}

export interface Order {
  id: string;
  tableId: string;
  items: OrderItem[];
  total: number;
  timestamp: string;
  status: 'PENDING' | 'COMPLETED';
  orderedBy: string;
}

export interface Table {
  id: string;
  number: string;
  type: 'VIP' | 'REGULAR' | 'BAR';
  status: 'AVAILABLE' | 'RESERVED' | 'OCCUPIED';
  capacity: number;
  assignedMemberId?: string;
}

export interface Transaction {
  id: string;
  memberId: string;
  type: 'TOPUP' | 'ORDER';
  amount: number;
  timestamp: string;
  description: string;
}

export interface Member {
  id: string;
  name: string;
  phone: string;
  balance: number;
  discountRate: number;
  registeredBy: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'ORDER' | 'ATTENDANCE' | 'SYSTEM';
}

// Added Attendance interface for employee shift tracking
export interface Attendance {
  id: string;
  userId: string;
  date: string;
  checkIn: string;
  checkOut: string | null;
  location: { lat: number; lng: number };
}

// Added Sale interface for PR performance and sales tracking
export interface Sale {
  id: string;
  prId: string;
  customerId: string;
  amount: number;
  giftValue: number;
  paymentMethod: 'CASH' | 'CREDIT' | 'DEBT';
  timestamp: string;
  uploadedBy: string;
}
